var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./GradientFill/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./GradientFill/index.ts":
/*!*******************************!*\
  !*** ./GradientFill/index.ts ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar GradientFill =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function GradientFill() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  GradientFill.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    this.controlId = Random.newString(); // Need to track container resize so that control could get the available width. The available height won't be provided even this is true\n\n    context.mode.trackContainerResize(true);\n    this.contextObj = context; // Create main table container div. \n\n    this.mainContainer = document.createElement(\"div\");\n    this.mainContainer.classList.add(\"main-container\"); // Create data table container div. \n\n    this.svgContainer = document.createElement(\"div\");\n    this.svgContainer.classList.add(\"svg-container\");\n    this.svgContainer.setAttribute(\"id\", \"svg-container\");\n    this.svgContainer.innerHTML = \"<svg width='500' height='500' viewBox='0 0 500 500'>\" + \"<defs>\";\n    \"<linearGradient id='\" + this.controlId + \"gradient'>\";\n    \"<stop offset='4%'  stop-color='black' />\" + \"<stop offset='94%' stop-color='white' />\" + \"</linearGradient>\" + \"</defs>\" + \"<g>\" + \"<rect x='0' y='0' width='500' height='500' style='fill: url(\\\"#\" + this.controlId + \"gradient\\\");'></rect>\" + \"</g>\" + \"</svg>\";\n    container.appendChild(this.mainContainer);\n    this.mainContainer.appendChild(this.svgContainer);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  GradientFill.prototype.updateView = function (context) {\n    var _a, _b;\n\n    var offset;\n    var color;\n    var gradients = \"\";\n\n    if (context.parameters.rotation != null) {\n      this.rotation = context.parameters.rotation.raw;\n    }\n\n    if (context.parameters.controlWidth != null) {\n      if (context.parameters.controlWidth.raw != null) this.controlWidth = context.parameters.controlWidth.raw;\n    }\n\n    if (context.parameters.controlHeight != null) {\n      if (context.parameters.controlHeight.raw != null) this.controlHeight = context.parameters.controlHeight.raw;\n    }\n\n    if (context.parameters.offsetStart != null) {\n      if (context.parameters.offsetStart.raw != null) this.offsetStart = context.parameters.offsetStart.raw;\n    }\n\n    if (context.parameters.offsetEnd != null) {\n      if (context.parameters.offsetEnd.raw != null) this.offsetEnd = context.parameters.offsetEnd.raw;\n    }\n\n    if (context.parameters.shape != null) {\n      if (context.parameters.shape.raw != null) this.shape = Shape[context.parameters.shape.raw];\n    }\n\n    if (context.parameters.gradient != null) {\n      if (context.parameters.gradient.raw != null) this.gradient = Gradient[context.parameters.gradient.raw];\n    } // Add code to update control view\n\n\n    if (!this.contextObj.parameters.GradientDataSet.loading) {\n      if (this.contextObj.parameters.GradientDataSet.sortedRecordIds.length > 0) {\n        for (var _i = 0, _c = this.contextObj.parameters.GradientDataSet.sortedRecordIds; _i < _c.length; _i++) {\n          var currentRecordId = _c[_i];\n          offset = parseInt(this.contextObj.parameters.GradientDataSet.records[currentRecordId].getFormattedValue(\"offset\"));\n          color = this.contextObj.parameters.GradientDataSet.records[currentRecordId].getFormattedValue(\"color\");\n          gradients = gradients + \"<stop offset='\" + offset.toString() + \"%'  stop-color='\" + color + \"' />\";\n        }\n\n        var ratio = 1;\n        if (this.controlWidth != null && this.controlHeight != null) ratio = this.controlHeight / this.controlWidth;\n        if (this.shape == Shape.Rectangle) this.shapeElement = \"<rect x='0' y='0' width='\" + this.controlWidth + \"' height='\" + this.controlHeight + \"' style='fill: url(\\\"#\" + this.controlId + \"gradient\\\");'></rect>\";else this.shapeElement = \"<circle cx='\" + this.controlWidth / 2 + \"' cy='\" + this.controlHeight / 2 + \"' r='\" + this.controlWidth / 2 + \"' style='fill: url(\\\"#\" + this.controlId + \"gradient\\\");'></circle>\";\n\n        if (this.gradient == Gradient.Linear) {\n          this.gradientElement = \"<linearGradient id='\" + this.controlId + \"gradient' gradientUnits='userSpaceOnUse' x1='\" + this.offsetStart + \"%' x2='\" + (100 - this.offsetEnd) + \"%' y1='100%' y2='100%' gradientTransform='rotate(\" + ((_a = this.rotation) === null || _a === void 0 ? void 0 : _a.toString()) + \", \" + this.controlWidth / 2 + \", \" + this.controlHeight / 2 + \")'>\" + gradients + \"</linearGradient>\";\n        } else {\n          this.gradientElement = \"<radialGradient id='\" + this.controlId + \"gradient' gradientUnits='userSpaceOnUse' cx='\" + this.offsetStart + \"%' cy='\" + this.offsetEnd + \"%' r='50%' fx='\" + this.offsetStart + \"%' fy='\" + this.offsetEnd + \"%' gradientTransform='rotate(\" + ((_b = this.rotation) === null || _b === void 0 ? void 0 : _b.toString()) + \", \" + this.controlWidth / 2 + \", \" + this.controlHeight / 2 + \")'>\" + gradients + \"</radialGradient>\";\n        }\n\n        this.svgContainer.innerHTML = \"<svg width='\" + this.controlWidth + \"' height='\" + this.controlHeight + \"' viewBox='0 0 \" + this.controlWidth + \" \" + this.controlHeight + \"'>\" + \"<defs>\" + this.gradientElement + \"</defs>\" + \"<g>\" + this.shapeElement + \"</g>\" + \"</svg>\";\n      }\n    }\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  GradientFill.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  GradientFill.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return GradientFill;\n}();\n\nexports.GradientFill = GradientFill;\nvar Shape;\n\n(function (Shape) {\n  Shape[\"Rectangle\"] = \"Rectangle\";\n  Shape[\"Circle\"] = \"Circle\";\n})(Shape || (Shape = {}));\n\nvar Gradient;\n\n(function (Gradient) {\n  Gradient[\"Linear\"] = \"Linear\";\n  Gradient[\"Radial\"] = \"Radial\";\n})(Gradient || (Gradient = {}));\n\nvar Random =\n/** @class */\nfunction () {\n  function Random() {}\n\n  Random.newString = function () {\n    return 'axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'.replace(/[xy]/g, function (c) {\n      var r = Math.random() * 16 | 0,\n          v = c == 'x' ? r : r & 0x3 | 0x8;\n      return v.toString(16);\n    });\n  };\n\n  return Random;\n}();\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./GradientFill/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('PowerAppsGuy.GradientFill', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.GradientFill);
} else {
	var PowerAppsGuy = PowerAppsGuy || {};
	PowerAppsGuy.GradientFill = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.GradientFill;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}